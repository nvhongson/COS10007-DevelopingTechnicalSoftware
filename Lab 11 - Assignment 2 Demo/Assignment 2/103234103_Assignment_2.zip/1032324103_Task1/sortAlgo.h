#include "structDef.h"

void BubbleSort(struct myStruct* structArr, int arrSize, char sortOption);
void InsertionSort(struct myStruct* structArr, int arrSize, char sortOption);
