#include "structDef.h"

void menu();
void printArray(struct myStruct* structArr, int arr_size);
int compareStrings(char *a, char *b);
void printArraytoFile(struct myStruct* structArr, int arr_size);
void convertArraytoList(struct myStruct* structArr, int arr_size);

