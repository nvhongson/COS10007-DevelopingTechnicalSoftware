#include "structDef.h"

int LinearSearch(struct myStruct* structArr, int arr_size, char* searchString, int index);
int BinarySearch(struct myStruct* structArr, char* searchString, int low, int high);

