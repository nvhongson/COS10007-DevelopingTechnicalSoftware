#ifndef STRUCTDEF_H
#define STRUCTDEF_H

struct myStruct {
        char strVal[20];
        int int1Val;
        int int2Val;
        double dblVal;
}; 

#endif
